import React from "react";
import HeaderNavigation from "./HeaderNavigation";

const AppLogo: React.FC = () => (
  <div className="flex items-center gap-1.5">
    <div className="w-6 h-6 rounded-md bg-indigo-600 flex items-center justify-center">
      <span className="text-white text-xs font-bold select-none">A</span>
    </div>
    <span className="text-sm font-semibold text-gray-900">Acme</span>
  </div>
);

const HeaderNavigationDemo: React.FC = () => {
  const back = () => alert("Back!");

  return (
    <div className="flex flex-col gap-6 p-6 bg-gray-50 min-h-screen">
      <p className="text-xs font-medium text-gray-400 uppercase tracking-widest">
        HeaderNavigation — variants
      </p>

      {/* Default */}
      <Section label="Default (title)">
        <HeaderNavigation onBack={back} title="Order Details" />
      </Section>

      {/* Logo */}
      <Section label="Default (logo)">
        <HeaderNavigation onBack={back} logo={<AppLogo />} />
      </Section>

      {/* Back only */}
      <Section label="Back arrow only">
        <HeaderNavigation onBack={back} />
      </Section>

      {/* Sizes */}
      <Section label='size="sm"'>
        <HeaderNavigation onBack={back} title="Small Header" size="sm" />
      </Section>
      <Section label='size="lg"'>
        <HeaderNavigation onBack={back} title="Large Header" size="lg" />
      </Section>

      {/* Transparent variant */}
      <Section label='variant="transparent"'>
        <div className="bg-gradient-to-r from-indigo-500 to-purple-500">
          <HeaderNavigation
            onBack={back}
            title="Transparent"
            variant="transparent"
            titleClassName="text-white"
            backButtonClassName="text-white hover:bg-white/20 active:bg-white/30"
          />
        </div>
      </Section>

      {/* Blurred variant */}
      <Section label='variant="blurred"'>
        <div className="bg-gradient-to-r from-sky-400 to-cyan-300">
          <HeaderNavigation
            onBack={back}
            title="Blurred"
            variant="blurred"
          />
        </div>
      </Section>

      {/* className override — twMerge resolves bg conflict */}
      <Section label="className override (bg-gray-900)">
        <HeaderNavigation
          onBack={back}
          title="Dark Header"
          className="bg-gray-900 border-gray-800"
          titleClassName="text-white"
          backButtonClassName="text-white hover:bg-white/10 active:bg-white/20"
        />
      </Section>

      {/* Long title truncation */}
      <Section label="Long title truncates">
        <HeaderNavigation
          onBack={back}
          title="This is a very long page title that will be truncated"
        />
      </Section>
    </div>
  );
};

// Small helper to keep demo tidy
const Section: React.FC<{ label: string; children: React.ReactNode }> = ({
  label,
  children,
}) => (
  <div className="flex flex-col gap-1">
    <p className="text-xs text-gray-400 pl-1">{label}</p>
    <div className="w-full max-w-sm rounded-2xl overflow-hidden shadow-sm border border-gray-200">
      {children}
      <div className="h-16 bg-white flex items-center justify-center text-sm text-gray-300">
        page content
      </div>
    </div>
  </div>
);

export default HeaderNavigationDemo;
