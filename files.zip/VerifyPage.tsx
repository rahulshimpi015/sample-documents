"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { OTPInput, OTPInputHandle } from "./OTPInput";
import { cn } from "@/utils/cn";

// ─────────────────────────────────────────────────────────────────────────────
// Config
// ─────────────────────────────────────────────────────────────────────────────

const COOLDOWN_SECONDS = 30;
const LS_KEY = "otp_sent_at"; // persists the send timestamp across reloads

// ─────────────────────────────────────────────────────────────────────────────
// Helper
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Reads the last OTP send time from localStorage and returns how many seconds
 * of the cooldown remain. Returns 0 when the cooldown has expired or on any
 * error (private browsing, SSR).
 */
function getSecondsLeft(): number {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return 0;
    const elapsed = Math.floor((Date.now() - parseInt(raw, 10)) / 1000);
    return Math.max(0, COOLDOWN_SECONDS - elapsed);
  } catch {
    return 0;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Component
// ─────────────────────────────────────────────────────────────────────────────

export default function VerifyPage() {
  const otpRef = useRef<OTPInputHandle>(null);
  const [isComplete, setIsComplete] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  // Initialised to 0 to avoid an SSR/hydration mismatch; real value is set in
  // the mount effect below.
  const [secondsLeft, setSecondsLeft] = useState(0);

  // ── Restore cooldown from localStorage on mount ──────────────────────────
  useEffect(() => {
    const remaining = getSecondsLeft();
    if (remaining > 0) setSecondsLeft(remaining);
  }, []);

  // ── Countdown tick ────────────────────────────────────────────────────────
  // A new interval is created each time secondsLeft becomes > 0 (i.e. after a
  // fresh Resend or after the mount-time restore above).
  useEffect(() => {
    if (secondsLeft <= 0) return;

    const id = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          clearInterval(id);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(id);
  }, [secondsLeft]);

  // ── Handlers ─────────────────────────────────────────────────────────────

  const handleResend = useCallback(() => {
    // Dismiss the soft keyboard so it doesn't jump when cells clear
    (document.activeElement as HTMLElement)?.blur();

    // Stamp the current time so reloads can resume the correct remaining time
    try {
      localStorage.setItem(LS_KEY, Date.now().toString());
    } catch { /* ignore — timer still works in-memory */ }

    setSecondsLeft(COOLDOWN_SECONDS);
    otpRef.current?.reset();
    setError("");

    // TODO: call your resend OTP API here
  }, []);

  const handleVerify = async () => {
    const code = otpRef.current?.getValue();
    if (!code) return;

    setIsLoading(true);
    setError("");

    try {
      // TODO: call your verify OTP API here
      await verifyOtp(code);
    } catch {
      setError("Invalid code. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const canResend = secondsLeft === 0 && !isLoading;
  const circumference = 2 * Math.PI * 15; // used for the SVG progress ring

  // ── Render ────────────────────────────────────────────────────────────────

  return (
    <div className="flex flex-col w-full">
      {/* OTP cells */}
      <OTPInput
        ref={otpRef}
        error={error}
        isLoading={isLoading}
        onCompleteChange={setIsComplete}
        onBack={() => {
          // TODO: handle navigation back
        }}
      />

      {/*
        Action bar
        · Mobile  (default) → fixed to the bottom of the viewport so the
                               soft keyboard never pushes the buttons off-screen
        · Desktop (sm:)     → sits in normal document flow inside the card
      */}
      <div
        className={cn(
          "flex flex-col gap-2.5 z-10 w-full",
          // Mobile — fixed bar
          "fixed bottom-0 left-0 right-0",
          "px-5 pt-3 pb-[calc(env(safe-area-inset-bottom)+12px)]",
          "bg-[#eae8e4] border-t border-stone-200",
          // Desktop — normal flow
          "sm:relative sm:bottom-auto sm:left-auto sm:right-auto",
          "sm:px-0 sm:pt-0 sm:pb-0",
          "sm:bg-transparent sm:border-t-0"
        )}
      >
        {/* Resend */}
        <button
          type="button"
          onClick={handleResend}
          disabled={!canResend}
          aria-label={
            secondsLeft > 0
              ? `Resend available in ${secondsLeft} seconds`
              : "Resend the code"
          }
          className="w-full py-3.5 sm:py-4 bg-transparent border border-stone-800 rounded-md text-stone-900 text-sm sm:text-base font-medium tracking-wide hover:bg-stone-900/5 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
        >
          {secondsLeft > 0 ? (
            <span className="flex items-center justify-center gap-2">
              {/*
                Circular countdown ring.
                Rotated -90° so the arc starts at 12 o'clock.
                strokeDashoffset decreases from circumference → 0 as time runs out.
              */}
              <svg
                width="16"
                height="16"
                viewBox="0 0 36 36"
                className="-rotate-90"
                aria-hidden
              >
                {/* Background track */}
                <circle
                  cx="18" cy="18" r="15"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="3"
                  strokeOpacity="0.25"
                />
                {/* Animated arc */}
                <circle
                  cx="18" cy="18" r="15"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="3"
                  strokeLinecap="round"
                  strokeDasharray={String(circumference)}
                  strokeDashoffset={String(
                    circumference * (1 - secondsLeft / COOLDOWN_SECONDS)
                  )}
                  className="transition-[stroke-dashoffset] duration-1000 ease-linear"
                />
              </svg>
              Resend in {secondsLeft}s
            </span>
          ) : (
            "Resend the code"
          )}
        </button>

        {/* Verify */}
        <button
          type="button"
          onClick={handleVerify}
          disabled={!isComplete || isLoading}
          className={cn(
            "w-full py-3.5 sm:py-4 rounded-md text-sm sm:text-base font-medium tracking-wide transition-all duration-200",
            isComplete && !isLoading
              ? "bg-[#1db89a] border border-[#1db89a] text-white hover:bg-[#17a688] hover:border-[#17a688]"
              : "bg-transparent border border-stone-800 text-stone-900 opacity-40 cursor-not-allowed"
          )}
        >
          {isLoading ? (
            <span className="flex items-center justify-center gap-2">
              <svg
                className="w-5 h-5 animate-spin"
                viewBox="0 0 24 24"
                fill="none"
                aria-hidden
              >
                <circle
                  cx="12" cy="12" r="10"
                  stroke="currentColor"
                  strokeWidth="3"
                  strokeDasharray="31.4"
                  strokeDashoffset="10"
                  strokeLinecap="round"
                />
              </svg>
              Verifying...
            </span>
          ) : (
            "Verify"
          )}
        </button>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// TODO: replace with your real API call
// ─────────────────────────────────────────────────────────────────────────────

async function verifyOtp(_code: string): Promise<void> {
  // Example:
  // const res = await fetch("/api/otp/verify", {
  //   method: "POST",
  //   body: JSON.stringify({ code: _code }),
  // });
  // if (!res.ok) throw new Error("Invalid OTP");
  throw new Error("verifyOtp not implemented");
}
