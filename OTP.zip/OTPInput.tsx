"use client";

import {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from "react";
import Input from "@/components/Input";
import { cn } from "@/utils/cn";

// ─────────────────────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────────────────────

export interface OTPInputHandle {
  /** Clears all cells and re-focuses the first one. */
  reset: () => void;
  /** Returns the full OTP string when all cells are filled, otherwise "". */
  getValue: () => string;
  /**
   * Reads the clipboard and fills the cells with any digits found.
   * Called by the parent's "Paste from clipboard" button.
   * Returns true if digits were found and filled, false otherwise.
   */
  pasteFromClipboard: () => Promise<boolean>;
}

interface OTPInputProps {
  /** Number of digit cells. Default: 6 */
  length?: number;
  /** Called on every keystroke with the current (possibly partial) value. */
  onChange?: (code: string) => void;
  /** Called once when all cells are filled. */
  onComplete?: (code: string) => void;
  /**
   * Called whenever the filled/empty state flips.
   * Use this in the parent to enable or disable the Verify button.
   */
  onCompleteChange?: (isComplete: boolean) => void;
  /** Called when the back arrow is pressed. */
  onBack?: () => void;
  /** Red error text shown below the cells — also triggers a shake animation. */
  error?: string;
  /** Disables all cells (e.g. while an API call is in flight). */
  isLoading?: boolean;
  /** Permanently disables all cells. */
  disabled?: boolean;
  /** Auto-focus the first cell on mount. Default: true */
  autoFocus?: boolean;
  /** Small ALL-CAPS label at the top of the card. */
  topLabel?: string;
  /** Large serif heading. */
  title?: string;
  /** Paragraph below the heading. */
  description?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// Helper — cell class names
// ─────────────────────────────────────────────────────────────────────────────

function getCellClassName(
  index: number,
  digit: string,
  focused: number | null,
  hasError: boolean
): string {
  return cn(
    "!w-10 sm:!w-14",
    "!h-12 sm:!h-16",
    "!px-0 !py-0",
    "text-center text-2xl sm:text-3xl font-serif",
    "transition-all duration-150",
    // Error state
    hasError && "!border-b-red-600 !text-red-600 !caret-red-600",
    // Focused (no error)
    !hasError && focused === index && "!border-b-stone-900 -translate-y-0.5",
    // Filled but not focused (no error)
    !hasError && focused !== index && digit && "!border-b-stone-900 !text-stone-900",
    // Empty and not focused (no error)
    !hasError && focused !== index && !digit && "!border-b-stone-400"
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Component
// ─────────────────────────────────────────────────────────────────────────────

export const OTPInput = forwardRef<OTPInputHandle, OTPInputProps>(
  function OTPInput(
    {
      length = 6,
      onChange,
      onComplete,
      onCompleteChange,
      onBack,
      error = "",
      isLoading = false,
      disabled = false,
      autoFocus = true,
      topLabel = "ACCOUNT CREATION",
      title = "We've sent you a code",
      description = "Enter the code we sent to your email address.",
    },
    ref
  ) {
    const [otp, setOtp] = useState<string[]>(Array(length).fill(""));
    const [focused, setFocused] = useState<number | null>(null);
    const [shake, setShake] = useState(false);
    const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

    // Keep a ref to the latest otp so the imperative handle never closes over
    // a stale value. Synced in an effect (not during render) to satisfy the
    // react-compiler "cannot update ref during render" rule.
    const otpRef = useRef(otp);
    useEffect(() => {
      otpRef.current = otp;
    });

    const hasError = !!error;
    const isInteractive = !disabled && !isLoading;

    // ── Imperative API ───────────────────────────────────────────────────────
    useImperativeHandle(
      ref,
      () => ({
        reset() {
          const empty = Array(length).fill("");
          setOtp(empty);
          onChange?.("");
          onCompleteChange?.(false);
          // Defer focus so the DOM has settled after state update.
          setTimeout(() => inputRefs.current[0]?.focus(), 0);
        },
        getValue() {
          const current = otpRef.current;
          return current.every((d) => d !== "") ? current.join("") : "";
        },
        async pasteFromClipboard() {
          try {
            const text = await navigator.clipboard.readText();
            const digits = text.replace(/\D/g, "").slice(0, length);
            if (!digits) return false;
            const next = Array(length).fill("");
            digits.split("").forEach((char, i) => { next[i] = char; });
            updateOtp(next);
            inputRefs.current[Math.min(digits.length, length - 1)]?.focus();
            return true;
          } catch {
            // Clipboard permission denied or API unavailable
            return false;
          }
        },
      }),
      [length, onChange, onCompleteChange, updateOtp]
    );

    // ── Auto-focus ───────────────────────────────────────────────────────────
    useEffect(() => {
      if (autoFocus) inputRefs.current[0]?.focus();
    }, [autoFocus]);

    // ── WebOTP API — Android SMS autofill ────────────────────────────────────
    // Works on Chrome for Android 84+. Silently ignored on iOS and desktop
    // (iOS relies on autocomplete="one-time-code" on the input element, which
    // shows a code suggestion in the keyboard toolbar — no JS needed there).
    //
    // Requires the SMS to end with an origin-bound suffix, e.g.:
    //   "Your code is 123456\n@yourdomain.com #123456"
    //
    // Flow:
    //   1. Browser intercepts the SMS matching the current origin.
    //   2. Shows a bottom-sheet: "Use code 123456 for yourdomain.com?"
    //   3. On tap, credentials.get() resolves with { code: "123456" }.
    //   4. We fill all cells and fire onChange / onComplete / onCompleteChange.
    useEffect(() => {
      if (
        typeof window === "undefined" ||
        !("OTPCredential" in window) ||
        !isInteractive
      ) return;

      const ac = new AbortController();

      (navigator.credentials.get as (opts: object) => Promise<{ code: string }>)({
        otp: { transport: ["sms"] },
        signal: ac.signal,
      })
        .then(({ code }) => {
          const digits = code.replace(/\D/g, "").slice(0, length);
          if (!digits) return;
          const next = Array(length).fill("");
          digits.split("").forEach((char, i) => { next[i] = char; });
          updateOtp(next);
          inputRefs.current[Math.min(digits.length, length - 1)]?.focus();
        })
        .catch(() => {
          // AbortError on unmount, NotAllowedError if user dismissed — both safe to ignore
        });

      return () => ac.abort();
    }, [isInteractive, length, updateOtp]);

    // ── Shake on new error ───────────────────────────────────────────────────
    useEffect(() => {
      if (!error) return;
      setShake(true);
      const id = setTimeout(() => setShake(false), 600);
      return () => clearTimeout(id);
    }, [error]);

    // ── Centralised OTP updater ──────────────────────────────────────────────
    const updateOtp = useCallback(
      (next: string[]) => {
        const complete = next.every((d) => d !== "");
        setOtp(next);
        onChange?.(next.join(""));
        onCompleteChange?.(complete);
        if (complete) onComplete?.(next.join(""));
      },
      [onChange, onComplete, onCompleteChange]
    );

    // ── Input handlers ───────────────────────────────────────────────────────
    const handleChange = (index: number, value: string) => {
      const digit = value.replace(/\D/g, "").slice(-1);
      const next = [...otp];
      next[index] = digit;
      updateOtp(next);
      if (digit && index < length - 1) inputRefs.current[index + 1]?.focus();
    };

    const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
      switch (e.key) {
        case "Backspace":
          if (otp[index]) {
            const next = [...otp];
            next[index] = "";
            updateOtp(next);
          } else if (index > 0) {
            inputRefs.current[index - 1]?.focus();
            const next = [...otp];
            next[index - 1] = "";
            updateOtp(next);
          }
          break;
        case "ArrowLeft":
          if (index > 0) inputRefs.current[index - 1]?.focus();
          break;
        case "ArrowRight":
          if (index < length - 1) inputRefs.current[index + 1]?.focus();
          break;
      }
    };

    const handlePaste = (e: React.ClipboardEvent<HTMLDivElement>) => {
      e.preventDefault();
      const pasted = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, length);
      if (!pasted) return;
      const next = Array(length).fill("");
      pasted.split("").forEach((char, i) => { next[i] = char; });
      updateOtp(next);
      inputRefs.current[Math.min(pasted.length, length - 1)]?.focus();
    };

    // ── Render ───────────────────────────────────────────────────────────────
    return (
      <div
        className={cn(
          "flex flex-col w-full",
          // Extra bottom padding so the fixed action bar never overlaps the cells
          // on mobile. Removed on sm+ where the bar is in normal flow.
          "pb-36 sm:pb-0",
          shake && "animate-[otpShake_0.55s_ease]"
        )}
      >
        {/* Top nav */}
        <div className="flex items-center justify-between mb-10 sm:mb-12">
          <button
            type="button"
            onClick={onBack}
            aria-label="Go back"
            className="flex items-center gap-1 text-stone-700 bg-transparent border-0 p-1 cursor-pointer hover:opacity-60 transition-opacity"
          >
            <svg width="18" height="14" viewBox="0 0 20 16" fill="none" aria-hidden>
              <path
                d="M8 1L1 8L8 15"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <line
                x1="1" y1="8" x2="19" y2="8"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
              />
            </svg>
            <span className="text-[10px] tracking-widest leading-none" aria-hidden>
              ·····
            </span>
          </button>

          <span className="text-[10px] font-medium tracking-[0.18em] text-stone-700 uppercase select-none">
            {topLabel}
          </span>

          {/* Spacer — keeps the label centred */}
          <div className="w-14" aria-hidden />
        </div>

        {/* Heading */}
        <div className="text-center mb-8 sm:mb-10">
          <h1 className="font-serif text-[2rem] sm:text-[2.5rem] font-normal leading-tight text-stone-900 tracking-tight mb-3">
            {title}
          </h1>
          <p className="text-sm sm:text-base text-stone-500 leading-relaxed">
            {description}
          </p>
        </div>

        {/* OTP cells */}
        <div
          role="group"
          aria-label="One-time password input"
          className="flex justify-center gap-2 sm:gap-3"
          onPaste={handlePaste}
        >
          {otp.map((digit, index) => (
            <Input
              key={index}
              ref={(el) => { inputRefs.current[index] = el; }}
              id={`otp-digit-${index}`}
              type="text"
              inputMode="numeric"
              maxLength={1}
              value={digit}
              autoComplete={index === 0 ? "one-time-code" : "off"}
              disabled={!isInteractive}
              variant={hasError ? "error" : "default"}
              className={getCellClassName(index, digit, focused, hasError)}
              onChange={(e) => handleChange(index, e.target.value)}
              onKeyDown={(e) => handleKeyDown(index, e)}
              onFocus={() => setFocused(index)}
              onBlur={() => setFocused(null)}
              aria-label={`Digit ${index + 1} of ${length}`}
            />
          ))}
        </div>

        {/* Error message */}
        {hasError && (
          <p role="alert" className="text-red-600 text-sm mt-3 text-center">
            {error}
          </p>
        )}
      </div>
    );
  }
);
